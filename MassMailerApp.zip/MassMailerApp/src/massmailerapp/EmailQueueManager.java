package massmailerapp;

import java.util.concurrent.*;

public class EmailQueueManager {
    private final BlockingQueue<EmailTask> queue = new LinkedBlockingQueue<>();
    private ExecutorService executorService;
    private volatile boolean isRunning = false;

    // Thêm email vào hàng đợi
    public void addEmail(EmailTask task) {
        queue.offer(task);
    }

    // Bắt đầu tiến trình gửi
    public void startSending(String host, String port, String username, String password, long delayInMillis, EmailCallback callback) {
        if (isRunning) return;
        isRunning = true;

        executorService = Executors.newSingleThreadExecutor();
        executorService.submit(() -> {
            try {
                while (isRunning && !Thread.currentThread().isInterrupted()) {
                    // Lấy task từ hàng đợi (chờ tối đa 1 giây)
                    EmailTask task = queue.poll(1, TimeUnit.SECONDS);
                    if (task == null) {
                        // Hàng đợi trống thì kết thúc
                        if (queue.isEmpty()) {
                            break;
                        }
                        continue;
                    }

                    boolean success = false;
                    try {
                        success = SmtpMailSender.sendMail(host, port, username, password, task);
                    } catch (Throwable t) {
                        // Bắt cả Error (vd NoClassDefFoundError) để không bị nuốt lỗi
                        t.printStackTrace();
                    }

                    if (callback != null) {
                        try {
                            callback.onEmailProcessed(task.getRecipient(), success);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }

                    // Áp dụng độ trễ (delay) giữa các lần gửi
                    if (delayInMillis > 0 && !queue.isEmpty()) {
                        Thread.sleep(delayInMillis);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Throwable t) {
                t.printStackTrace();
            } finally {
                // Reset trạng thái để có thể bấm "Bắt đầu gửi" lần sau
                isRunning = false;
            }
        });
        executorService.shutdown(); // Executor tự đóng sau khi task chạy xong
    }

    // Dừng tiến trình gửi
    public void stopSending() {
        isRunning = false;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    // Lấy số lượng email còn lại trong hàng đợi
    public int getQueueSize() {
        return queue.size();
    }

    // Interface dùng để gọi ngược lại trạng thái khi xử lý xong một email
    public interface EmailCallback {
        void onEmailProcessed(String recipient, boolean success);
    }
}