package massmailerapp;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;

public class SmtpMailSender {
    public static boolean sendMail(String host, String port, String username, String password, EmailTask task) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);

        // THÊM CÁC THAM SỐ TIMEOUT NÀY ĐỂ TRÁNH BỊ TREO LUỒNG
        props.put("mail.smtp.connectiontimeout", "5000"); // 5 giây timeout kết nối
        props.put("mail.smtp.timeout", "5000");           // 5 giây timeout đọc dữ liệu
        props.put("mail.smtp.writetimeout", "5000");        // 5 giây timeout gửi dữ liệu

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(task.getRecipient()));
            message.setSubject(task.getSubject());
            message.setText(task.getContent());

            Transport.send(message);
            return true;
        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
    }
}